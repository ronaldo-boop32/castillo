export const CATEGORIES = [
  "colombiana",
  "mariscos",
  "rapidas",
  "internacional",
  "carnes",
  "postres",
  "helados",
  "bebidas",
  "cocteles",
] as const;

export type Category = (typeof CATEGORIES)[number];

export const CATEGORY_LABELS: Record<Category, string> = {
  colombiana: "Cocina costeña",
  mariscos: "Pescados y mariscos",
  rapidas: "Comidas rápidas",
  internacional: "Pizzas, pastas y más",
  carnes: "Carnes y parrilla",
  postres: "Postres",
  helados: "Helados",
  bebidas: "Bebidas",
  cocteles: "Cócteles",
};

export type CatalogProduct = {
  slug: string;
  name: string;
  description: string;
  category: Category;
  price: number;
  image: string;
  featured?: boolean;
};

const u = (n: number) => `/images/unsplash/foto-${String(n).padStart(2, "0")}.webp`;
const r = (name: string) => `/images/reales/${name}.webp`;

export const catalogSeed: CatalogProduct[] = [
  { slug: "bandeja-paisa", name: "Bandeja paisa", description: "Frijoles, arroz, carne molida, chicharrón, chorizo, huevo, maduro, arepa y aguacate.", category: "colombiana", price: 38000, image: r("bandeja-paisa"), featured: true },
  { slug: "mojarra-frita", name: "Mojarra frita", description: "Pescado entero dorado con arroz con coco, ensalada fresca y patacones.", category: "colombiana", price: 42000, image: r("mojarra-frita"), featured: true },
  { slug: "sancocho-guandu", name: "Sancocho de guandú", description: "Sopa costeña de guandú, verduras y carne salada, acompañada de arroz blanco.", category: "colombiana", price: 26000, image: r("sancocho-costeno") },
  { slug: "mote-queso", name: "Mote de queso", description: "Sopa cremosa de ñame con queso costeño y sofrito de la casa.", category: "colombiana", price: 23000, image: u(36) },
  { slug: "arroz-lisa", name: "Arroz de lisa", description: "Arroz sazonado con lisa, bollo de yuca y un toque de limón.", category: "colombiana", price: 22000, image: r("arroz-lisa") },
  { slug: "arepa-huevo", name: "Arepa de huevo", description: "Arepa de maíz frita y crujiente, rellena de huevo.", category: "colombiana", price: 8000, image: r("arepa-huevo"), featured: true },
  { slug: "cayeye-queso", name: "Cayeye con queso", description: "Puré de guineo verde con queso costeño, aguacate y sofrito.", category: "colombiana", price: 26900, image: u(46) },
  { slug: "patacones-hogao", name: "Patacones con hogao", description: "Plátano verde aplastado y frito con hogao de tomate y cebolla.", category: "colombiana", price: 15000, image: u(10) },

  { slug: "cazuela-mariscos", name: "Cazuela de mariscos", description: "Camarones, calamar y pescado en salsa cremosa con acompañamientos.", category: "mariscos", price: 48000, image: u(36), featured: true },
  { slug: "arroz-camarones", name: "Arroz con camarones", description: "Arroz sazonado con camarones y vegetales, con patacones.", category: "mariscos", price: 39000, image: u(11) },
  { slug: "coctel-camaron", name: "Cóctel de camarón", description: "Camarones fríos con salsa de la casa, limón y cebolla.", category: "mariscos", price: 28000, image: r("ceviche-mariscos") },
  { slug: "ceviche-pescado", name: "Ceviche de pescado", description: "Pescado marinado con limón, cebolla morada, cilantro y especias.", category: "mariscos", price: 32000, image: r("ceviche-pulpo") },
  { slug: "camarones-ajillo", name: "Camarones al ajillo", description: "Camarones salteados con ajo, mantequilla y perejil.", category: "mariscos", price: 35000, image: u(11) },
  { slug: "filete-apanado", name: "Filete de pescado apanado", description: "Filete empanizado y dorado con papas, ensalada y limón.", category: "mariscos", price: 32000, image: u(45) },
  { slug: "pulpo-parrilla", name: "Pulpo a la parrilla", description: "Pulpo asado con guarnición y salsa de la casa.", category: "mariscos", price: 56000, image: r("pulpo-parrilla") },
  { slug: "patacones-camarones", name: "Patacones con camarones", description: "Patacones crujientes con camarones y champiñones gratinados.", category: "mariscos", price: 38000, image: u(14) },

  { slug: "hamburguesa-clasica", name: "Hamburguesa clásica", description: "Res, queso, lechuga, tomate, pepinillos y salsa en pan tostado.", category: "rapidas", price: 28000, image: u(2), featured: true },
  { slug: "hamburguesa-doble", name: "Hamburguesa doble con tocineta", description: "Doble carne, cheddar, tocineta crujiente y salsa especial.", category: "rapidas", price: 42000, image: u(5) },
  { slug: "hamburguesa-pollo", name: "Hamburguesa de pollo crispy", description: "Pollo apanado con lechuga, tomate, mayonesa y pan suave.", category: "rapidas", price: 29000, image: u(3) },
  { slug: "perro-especial", name: "Perro caliente especial", description: "Salchicha, queso, papitas trituradas, salsas y aderezos.", category: "rapidas", price: 18000, image: r("perro-especial") },
  { slug: "salchipapa-especial", name: "Salchipapa especial", description: "Papas fritas con salchicha, queso costeño y salsas.", category: "rapidas", price: 22000, image: r("perro-especial") },
  { slug: "alitas-bbq", name: "Alitas BBQ", description: "Alitas de pollo con salsa barbacoa dulce y ahumada.", category: "rapidas", price: 32000, image: u(6) },
  { slug: "nuggets-pollo", name: "Nuggets de pollo", description: "Trozos de pollo empanizados con papas fritas y salsa.", category: "rapidas", price: 23000, image: u(6) },
  { slug: "sandwich-club", name: "Sándwich club", description: "Pollo, tocineta, huevo, queso, lechuga, tomate y alioli.", category: "rapidas", price: 49900, image: u(7) },

  { slug: "pizza-margarita", name: "Pizza margarita", description: "Masa horneada con salsa de tomate, mozzarella y albahaca.", category: "internacional", price: 39000, image: u(1), featured: true },
  { slug: "pizza-hawaiana", name: "Pizza hawaiana", description: "Jamón, piña, mozzarella y salsa de tomate.", category: "internacional", price: 42000, image: r("mini-pizzas") },
  { slug: "pizza-pepperoni", name: "Pizza pepperoni", description: "Mozzarella, pepperoni y salsa de tomate.", category: "internacional", price: 36000, image: u(1) },
  { slug: "lasana-bolonesa", name: "Lasaña boloñesa", description: "Capas de pasta, carne, tomate, bechamel y queso gratinado.", category: "internacional", price: 48900, image: u(12) },
  { slug: "pasta-carbonara", name: "Pasta carbonara", description: "Pasta con tocineta y salsa cremosa de la casa.", category: "internacional", price: 30000, image: u(12) },
  { slug: "fettuccine-camarones", name: "Fettuccine con camarones", description: "Pasta con camarones en salsa cremosa de coco y especias.", category: "internacional", price: 55000, image: u(11) },
  { slug: "sushi-salmon", name: "Sushi de salmón", description: "Rollos de arroz y alga nori con salmón, aguacate y queso crema.", category: "internacional", price: 35000, image: u(42) },
  { slug: "tacos-carne", name: "Tacos de carne", description: "Tortillas con carne asada, cebolla, cilantro y salsas.", category: "internacional", price: 28000, image: u(16) },

  { slug: "churrasco-parrilla", name: "Churrasco a la parrilla", description: "Corte de res asado con papas, ensalada y chimichurri.", category: "carnes", price: 48000, image: u(33), featured: true },
  { slug: "pechuga-plancha", name: "Pechuga a la plancha", description: "Pechuga de pollo asada con arroz, ensalada y papas.", category: "carnes", price: 32000, image: u(9) },
  { slug: "costillas-bbq", name: "Costillas BBQ", description: "Costillas de cerdo cocinadas lentamente con salsa barbacoa.", category: "carnes", price: 46000, image: u(32) },
  { slug: "quibbe", name: "Quibbe", description: "Bocado de trigo y carne sazonada de la cocina árabe y costeña.", category: "carnes", price: 5000, image: u(6) },

  { slug: "brownie-helado", name: "Brownie con helado", description: "Brownie húmedo de chocolate con helado de vainilla.", category: "postres", price: 19000, image: r("brownie-helado"), featured: true },
  { slug: "torta-chocolate", name: "Torta de chocolate", description: "Bizcocho de chocolate con relleno y cobertura de ganache.", category: "postres", price: 21900, image: u(18) },
  { slug: "cheesecake-frutos", name: "Cheesecake de frutos rojos", description: "Tarta cremosa de queso sobre galleta con frutos rojos.", category: "postres", price: 22900, image: u(20) },
  { slug: "tres-leches", name: "Torta tres leches", description: "Bizcocho húmedo con tres leches y cobertura de crema.", category: "postres", price: 16000, image: u(19) },

  { slug: "helado-vainilla", name: "Helado de vainilla", description: "Dos bolas cremosas de vainilla con barquillo.", category: "helados", price: 10000, image: u(23) },
  { slug: "helado-chocolate", name: "Helado de chocolate", description: "Dos bolas de chocolate con salsa y trozos de cacao.", category: "helados", price: 11000, image: u(22) },
  { slug: "helado-fresa", name: "Helado de fresa", description: "Helado artesanal de fresa con fruta fresca.", category: "helados", price: 11000, image: u(24) },
  { slug: "helado-arequipe", name: "Helado de arequipe", description: "Cremoso helado de arequipe con un toque de sal.", category: "helados", price: 12000, image: u(23) },
  { slug: "helado-galleta", name: "Helado cookies & cream", description: "Helado de vainilla con trozos de galleta de chocolate.", category: "helados", price: 13000, image: u(24) },

  { slug: "limonada-natural", name: "Limonada natural", description: "Limón, hielo y hierbabuena, preparada al momento.", category: "bebidas", price: 9000, image: r("limonada-hierbabuena") },
  { slug: "jugo-mango", name: "Jugo natural de mango", description: "Mango maduro batido con agua o leche.", category: "bebidas", price: 10000, image: u(29) },
  { slug: "gaseosa", name: "Gaseosa fría", description: "Bebida refrescante de 350 ml con hielo y limón.", category: "bebidas", price: 6000, image: u(28) },
  { slug: "te-helado", name: "Té helado de limón", description: "Té frío con limón, hielo y un toque de menta.", category: "bebidas", price: 9000, image: u(30) },
  { slug: "malteada-chocolate", name: "Malteada de chocolate", description: "Leche, helado y chocolate batidos hasta quedar cremosos.", category: "bebidas", price: 14000, image: u(22) },

  { slug: "mojito-clasico", name: "Mojito clásico", description: "Ron, hierbabuena, limón, azúcar y soda.", category: "cocteles", price: 22000, image: r("mojito-clasico"), featured: true },
  { slug: "pina-colada", name: "Piña colada", description: "Ron, crema de coco y jugo de piña.", category: "cocteles", price: 25000, image: u(25) },
  { slug: "margarita", name: "Margarita", description: "Tequila, licor de naranja, limón y borde de sal.", category: "cocteles", price: 24000, image: u(26) },
  { slug: "daiquiri-fresa", name: "Daiquiri de fresa", description: "Ron, fresas y limón frappé.", category: "cocteles", price: 24000, image: u(25) },
  { slug: "caipirina", name: "Caipiriña", description: "Cachaza, limón fresco, azúcar y mucho hielo.", category: "cocteles", price: 23000, image: r("mojito-copa") },

  { slug: "flan-caramelo", name: "Flan de caramelo", description: "Flan casero de vainilla con caramelo suave.", category: "postres", price: 12000, image: u(21) },
  { slug: "arroz-leche", name: "Arroz con leche", description: "Arroz cremoso con canela, pasas y leche.", category: "postres", price: 11000, image: u(21) },
  { slug: "fresas-crema", name: "Fresas con crema", description: "Fresas frescas con crema dulce y un toque de vainilla.", category: "postres", price: 14000, image: r("brownie-fresas") },
  { slug: "copa-brownie", name: "Copa brownie", description: "Brownie, helado de vainilla, fresas y salsa de chocolate.", category: "postres", price: 18000, image: r("copa-brownie") },
  { slug: "merengon-frutos", name: "Merengón de frutos rojos", description: "Merengue crujiente, crema y frutos rojos frescos.", category: "postres", price: 17000, image: u(20) },
];
