# Créditos y uso de fotografías

Las imágenes incluidas son fotografías gastronómicas de referencia y no representan platos preparados por un restaurante llamado Sabor Costeño.

## Fotografías de Unsplash

La carpeta `public/images/unsplash/` contiene 48 fotografías descargadas de Unsplash. El archivo `public/images/unsplash/sources.json` conserva la URL original de cada una.

- Fuente: https://unsplash.com/
- Licencia de Unsplash: https://unsplash.com/license

## Fotografías gastronómicas específicas

La carpeta `public/images/reales/` contiene 19 imágenes. Estas son sus páginas de procedencia:

| Archivo | Página de origen |
| --- | --- |
| `bandeja-paisa.webp` | https://www.semana.com/cocina/articulo/asi-se-prepara-la-bandeja-paisa-uno-de-los-platos-tipicos-colombianos/202339/ |
| `bandeja-costena.webp` | https://www.pequerecetas.com/receta/bandeja-paisa-colombiana/ |
| `ceviche-pulpo.webp` | https://weekdaypescatarian.com/octopus-ceviche-recipe/ |
| `pulpo-parrilla.webp` | https://weekdaypescatarian.com/how-to-serve-ceviche/ |
| `ceviche-mariscos.webp` | https://www.foodista.com/blog/2014/04/03/delicious-shrimp-and-octopus-ceviche |
| `perro-especial.webp` | https://www.mlive.com/business/2026/09/red-wings-games-will-be-packed-with-new-food-items-to-try-this-season.html |
| `mini-pizzas.webp` | https://rachlmansfield.com/epic-pizza-smash-burger-tacos/ |
| `brownie-helado.webp` | https://www.duncanhines.com/recipes/brownies/salted-caramel-brownie-ice-cream-cake-9772 |
| `brownie-fresas.webp` | https://www.thesumofallsweets.com/feature-dessert-strawberry-cheesecake-brownie/ |
| `mojito-clasico.webp` | https://www.thespruceeats.com/mojito-cocktail-recipe-759319 |
| `limonada-hierbabuena.webp` | https://legallyhealthyblonde.com/easy-lemonade-mojito/ |
| `mojito-coco.webp` | https://www.malibudrinks.com/en/drinks/malibu-mojito/ |
| `mojito-menta.webp` | https://www.loveandlemons.com/mojito-recipe/ |
| `mojito-copa.webp` | https://www.afarmgirlsdabbles.com/classic-mojito-recipe/ |
| `mojarra-frita.webp` | https://www.civitatis.com/blog/gastronomia-caribe-colombiano/ |
| `arepa-huevo.webp` | https://www.civitatis.com/blog/gastronomia-caribe-colombiano/ |
| `arroz-lisa.webp` | https://www.civitatis.com/blog/gastronomia-caribe-colombiano/ |
| `sancocho-costeno.webp` | https://matadornetwork.com/es/delicias-costa-caribe-colombiana/ |
| `copa-brownie.webp` | https://es.vecteezy.com/foto/2806089-helado-de-vainilla-con-tarta-de-brownie-de-chocolate-con-fresa-encima |

Los derechos de estas fotografías pertenecen a sus respectivos autores y titulares. Su inclusión está pensada para el prototipo solicitado. Antes de utilizar el proyecto con fines comerciales, revisa las condiciones de cada fuente, obtén los permisos necesarios o sustituye las imágenes por fotografías propias o con licencia comercial verificada.

## Tipografías

- Marcellus y Manrope, servidas mediante Google Fonts.
- Licencias disponibles en los repositorios de Google Fonts: https://fonts.google.com/
