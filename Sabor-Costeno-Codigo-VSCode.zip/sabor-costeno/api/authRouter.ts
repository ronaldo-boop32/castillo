import { z } from "zod";
import { eq } from "drizzle-orm";
import { TRPCError } from "@trpc/server";
import { users } from "@db/schema";
import { createRouter, publicQuery } from "./middleware";
import { getDb } from "./queries/connection";
import {
  createSession,
  destroySession,
  getCurrentUser,
  hashPassword,
  verifyPassword,
} from "./auth";

const credentials = z.object({
  email: z.string().trim().email("Escribe un correo válido.").max(320),
  password: z.string().min(8, "La contraseña debe tener al menos 8 caracteres.").max(100),
});

export const authRouter = createRouter({
  me: publicQuery.query(({ ctx }) => getCurrentUser(ctx)),

  register: publicQuery
    .input(credentials.extend({ name: z.string().trim().min(2, "Escribe tu nombre.").max(120) }))
    .mutation(async ({ ctx, input }) => {
      const email = input.email.toLowerCase();
      const [existing] = await getDb().select({ id: users.id }).from(users).where(eq(users.email, email)).limit(1);
      if (existing) throw new TRPCError({ code: "CONFLICT", message: "Ya existe una cuenta con este correo." });
      const [{ id }] = await getDb().insert(users).values({
        name: input.name,
        email,
        passwordHash: hashPassword(input.password),
        role: "user",
      }).$returningId();
      await createSession(id, ctx);
      return { id, name: input.name, email, role: "user" as const };
    }),

  login: publicQuery.input(credentials).mutation(async ({ ctx, input }) => {
    const email = input.email.toLowerCase();
    const [user] = await getDb().select().from(users).where(eq(users.email, email)).limit(1);
    if (!user || !verifyPassword(input.password, user.passwordHash)) {
      throw new TRPCError({ code: "UNAUTHORIZED", message: "El correo o la contraseña no coinciden." });
    }
    await createSession(user.id, ctx);
    return { id: user.id, name: user.name, email: user.email, role: user.role };
  }),

  logout: publicQuery.mutation(async ({ ctx }) => {
    await destroySession(ctx);
    return { ok: true };
  }),
});
