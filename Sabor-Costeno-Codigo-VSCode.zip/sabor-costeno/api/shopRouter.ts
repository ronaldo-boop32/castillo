import { z } from "zod";
import { asc, desc, eq, inArray } from "drizzle-orm";
import { TRPCError } from "@trpc/server";
import { orderItems, orders, products } from "@db/schema";
import { CATEGORIES } from "@contracts/catalog";
import { createRouter, publicQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { requireAdmin, requireUser } from "./auth";

const productInput = z.object({
  slug: z.string().trim().min(2).max(160).regex(/^[a-z0-9-]+$/, "Usa minúsculas, números y guiones."),
  name: z.string().trim().min(2).max(160),
  description: z.string().trim().min(10).max(1000),
  category: z.enum(CATEGORIES),
  price: z.number().int().min(0).max(10000000),
  image: z.string().trim().min(1).max(1000),
  featured: z.boolean(),
  available: z.boolean(),
});

export const shopRouter = createRouter({
  products: publicQuery.query(() => getDb().select().from(products).orderBy(asc(products.id))),

  createOrder: publicQuery
    .input(z.object({
      customerName: z.string().trim().min(2).max(120),
      phone: z.string().trim().min(7).max(30),
      address: z.string().trim().min(5).max(255),
      notes: z.string().trim().max(500).optional(),
      items: z.array(z.object({ productId: z.number().int().positive(), quantity: z.number().int().min(1).max(30) })).min(1).max(50),
    }))
    .mutation(async ({ ctx, input }) => {
      const user = await requireUser(ctx);
      const ids = input.items.map((item) => item.productId);
      const selected = await getDb().select().from(products).where(inArray(products.id, ids));
      if (selected.length !== new Set(ids).size || selected.some((product) => !product.available)) {
        throw new TRPCError({ code: "BAD_REQUEST", message: "Un producto ya no está disponible. Revisa tu carrito." });
      }
      const lines = input.items.map((item) => {
        const product = selected.find((candidate) => candidate.id === item.productId)!;
        return { product, quantity: item.quantity };
      });
      const total = lines.reduce((sum, line) => sum + line.product.price * line.quantity, 0);
      return getDb().transaction(async (tx) => {
        const [{ id }] = await tx.insert(orders).values({
          userId: user.id,
          customerName: input.customerName,
          phone: input.phone,
          address: input.address,
          notes: input.notes || null,
          total,
        }).$returningId();
        await tx.insert(orderItems).values(lines.map((line) => ({
          orderId: id,
          productId: line.product.id,
          productName: line.product.name,
          unitPrice: line.product.price,
          quantity: line.quantity,
        })));
        return { id, total, status: "pendiente" as const };
      });
    }),

  myOrders: publicQuery.query(async ({ ctx }) => {
    const user = await requireUser(ctx);
    const orderRows = await getDb().select().from(orders).where(eq(orders.userId, user.id)).orderBy(desc(orders.createdAt));
    if (!orderRows.length) return [];
    const items = await getDb().select().from(orderItems).where(inArray(orderItems.orderId, orderRows.map((order) => order.id)));
    return orderRows.map((order) => ({ ...order, items: items.filter((item) => item.orderId === order.id) }));
  }),

  adminOverview: publicQuery.query(async ({ ctx }) => {
    await requireAdmin(ctx);
    const [orderRows, productRows, itemRows] = await Promise.all([
      getDb().select().from(orders).orderBy(desc(orders.createdAt)),
      getDb().select().from(products).orderBy(desc(products.id)),
      getDb().select().from(orderItems),
    ]);
    return {
      orders: orderRows.map((order) => ({ ...order, items: itemRows.filter((item) => item.orderId === order.id) })),
      products: productRows,
      stats: {
        sales: orderRows.filter((order) => order.status !== "cancelado").reduce((sum, order) => sum + order.total, 0),
        pending: orderRows.filter((order) => order.status === "pendiente").length,
        products: productRows.length,
        orders: orderRows.length,
      },
    };
  }),

  updateOrderStatus: publicQuery
    .input(z.object({ id: z.number().int().positive(), status: z.enum(["pendiente", "preparando", "en_camino", "entregado", "cancelado"]) }))
    .mutation(async ({ ctx, input }) => {
      await requireAdmin(ctx);
      await getDb().update(orders).set({ status: input.status }).where(eq(orders.id, input.id));
      return { ok: true };
    }),

  createProduct: publicQuery.input(productInput).mutation(async ({ ctx, input }) => {
    await requireAdmin(ctx);
    const [{ id }] = await getDb().insert(products).values(input).$returningId();
    return { id };
  }),

  updateProduct: publicQuery
    .input(productInput.extend({ id: z.number().int().positive() }))
    .mutation(async ({ ctx, input }) => {
      await requireAdmin(ctx);
      const { id, ...values } = input;
      await getDb().update(products).set(values).where(eq(products.id, id));
      return { ok: true };
    }),

  deleteProduct: publicQuery
    .input(z.object({ id: z.number().int().positive() }))
    .mutation(async ({ ctx, input }) => {
      await requireAdmin(ctx);
      await getDb().delete(products).where(eq(products.id, input.id));
      return { ok: true };
    }),
});
