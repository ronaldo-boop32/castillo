import { createRouter, publicQuery } from "./middleware";
import { authRouter } from "./authRouter";
import { shopRouter } from "./shopRouter";

export const appRouter = createRouter({
  ping: publicQuery.query(() => ({ ok: true, ts: Date.now() })),
  auth: authRouter,
  shop: shopRouter,
});

export type AppRouter = typeof appRouter;
