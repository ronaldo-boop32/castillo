import { createHash, randomBytes, scryptSync, timingSafeEqual } from "node:crypto";
import { and, eq, gt } from "drizzle-orm";
import { TRPCError } from "@trpc/server";
import { sessions, users } from "@db/schema";
import { getDb } from "./queries/connection";
import type { TrpcContext } from "./context";

const COOKIE_NAME = "sabor_session";
const SESSION_DAYS = 30;

export function hashPassword(password: string) {
  const salt = randomBytes(16).toString("hex");
  const hash = scryptSync(password, salt, 64).toString("hex");
  return `${salt}:${hash}`;
}

export function verifyPassword(password: string, stored: string) {
  const [salt, hash] = stored.split(":");
  if (!salt || !hash) return false;
  const candidate = scryptSync(password, salt, 64);
  const expected = Buffer.from(hash, "hex");
  return candidate.length === expected.length && timingSafeEqual(candidate, expected);
}

function hashToken(token: string) {
  return createHash("sha256").update(token).digest("hex");
}

function secureCookie(ctx: TrpcContext) {
  const forwardedProtocol = ctx.req.headers.get("x-forwarded-proto")?.split(",")[0].trim();
  const isHttps = new URL(ctx.req.url).protocol === "https:" || forwardedProtocol === "https";
  return process.env.NODE_ENV === "production" && isHttps ? "; Secure" : "";
}

function tokenFromRequest(req: Request) {
  const cookies = req.headers.get("cookie") ?? "";
  const match = cookies.split(/;\s*/).find((part) => part.startsWith(`${COOKIE_NAME}=`));
  return match ? decodeURIComponent(match.slice(COOKIE_NAME.length + 1)) : null;
}

export async function createSession(userId: number, ctx: TrpcContext) {
  const token = randomBytes(32).toString("base64url");
  const expiresAt = new Date(Date.now() + SESSION_DAYS * 86400000);
  await getDb().insert(sessions).values({ tokenHash: hashToken(token), userId, expiresAt });
  const secure = secureCookie(ctx);
  ctx.resHeaders.append(
    "Set-Cookie",
    `${COOKIE_NAME}=${encodeURIComponent(token)}; HttpOnly; Path=/; SameSite=Lax; Max-Age=${SESSION_DAYS * 86400}${secure}`,
  );
}

export async function destroySession(ctx: TrpcContext) {
  const token = tokenFromRequest(ctx.req);
  if (token) await getDb().delete(sessions).where(eq(sessions.tokenHash, hashToken(token)));
  const secure = secureCookie(ctx);
  ctx.resHeaders.append(
    "Set-Cookie",
    `${COOKIE_NAME}=; HttpOnly; Path=/; SameSite=Lax; Max-Age=0${secure}`,
  );
}

export async function getCurrentUser(ctx: TrpcContext) {
  const token = tokenFromRequest(ctx.req);
  if (!token) return null;
  const [row] = await getDb()
    .select({ id: users.id, name: users.name, email: users.email, role: users.role })
    .from(sessions)
    .innerJoin(users, eq(sessions.userId, users.id))
    .where(and(eq(sessions.tokenHash, hashToken(token)), gt(sessions.expiresAt, new Date())))
    .limit(1);
  return row ?? null;
}

export async function requireUser(ctx: TrpcContext) {
  const user = await getCurrentUser(ctx);
  if (!user) throw new TRPCError({ code: "UNAUTHORIZED", message: "Inicia sesión para continuar." });
  return user;
}

export async function requireAdmin(ctx: TrpcContext) {
  const user = await requireUser(ctx);
  if (user.role !== "admin") {
    throw new TRPCError({ code: "FORBIDDEN", message: "Esta sección es solo para administradores." });
  }
  return user;
}
