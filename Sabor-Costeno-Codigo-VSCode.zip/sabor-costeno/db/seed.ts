import { getDb } from "../api/queries/connection";
import { products, users } from "./schema";
import { catalogSeed } from "@contracts/catalog";
import { hashPassword } from "../api/auth";

async function seed() {
  const db = getDb();
  console.log("Sembrando el catálogo y el administrador...");

  await db.insert(users).values({
    name: "Juan",
    email: "juan@saborcosteno.com",
    passwordHash: hashPassword("Juan2026!"),
    role: "admin",
  }).onDuplicateKeyUpdate({
    set: { name: "Juan", role: "admin", passwordHash: hashPassword("Juan2026!") },
  });

  for (const product of catalogSeed) {
    await db.insert(products).values({
      ...product,
      featured: product.featured ?? false,
      available: true,
    }).onDuplicateKeyUpdate({
      set: {
        name: product.name,
        description: product.description,
        category: product.category,
        price: product.price,
        image: product.image,
        featured: product.featured ?? false,
      },
    });
  }

  console.log(`Listo: ${catalogSeed.length} productos. Admin: juan@saborcosteno.com / Juan2026!`);
  process.exit(0);
}

seed().catch((error) => {
  console.error(error);
  process.exit(1);
});
