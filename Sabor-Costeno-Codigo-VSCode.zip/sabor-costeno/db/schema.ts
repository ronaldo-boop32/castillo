import {
  mysqlTable,
  mysqlEnum,
  serial,
  varchar,
  text,
  timestamp,
  bigint,
  int,
  boolean,
  index,
} from "drizzle-orm/mysql-core";
import { CATEGORIES } from "@contracts/catalog";

export const users = mysqlTable("users", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 120 }).notNull(),
  email: varchar("email", { length: 320 }).notNull().unique(),
  passwordHash: text("passwordHash").notNull(),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const sessions = mysqlTable(
  "sessions",
  {
    id: serial("id").primaryKey(),
    tokenHash: varchar("tokenHash", { length: 64 }).notNull().unique(),
    userId: bigint("userId", { mode: "number", unsigned: true })
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    expiresAt: timestamp("expiresAt").notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  (table) => ({ userIdx: index("sessions_user_idx").on(table.userId) }),
);

export const products = mysqlTable("products", {
  id: serial("id").primaryKey(),
  slug: varchar("slug", { length: 160 }).notNull().unique(),
  name: varchar("name", { length: 160 }).notNull(),
  description: text("description").notNull(),
  category: mysqlEnum("category", CATEGORIES).notNull(),
  price: int("price").notNull(),
  image: text("image").notNull(),
  featured: boolean("featured").default(false).notNull(),
  available: boolean("available").default(true).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const orders = mysqlTable(
  "orders",
  {
    id: serial("id").primaryKey(),
    userId: bigint("userId", { mode: "number", unsigned: true })
      .notNull()
      .references(() => users.id),
    customerName: varchar("customerName", { length: 120 }).notNull(),
    phone: varchar("phone", { length: 30 }).notNull(),
    address: varchar("address", { length: 255 }).notNull(),
    notes: text("notes"),
    status: mysqlEnum("status", [
      "pendiente",
      "preparando",
      "en_camino",
      "entregado",
      "cancelado",
    ]).default("pendiente").notNull(),
    total: int("total").notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  (table) => ({ userIdx: index("orders_user_idx").on(table.userId) }),
);

export const orderItems = mysqlTable(
  "order_items",
  {
    id: serial("id").primaryKey(),
    orderId: bigint("orderId", { mode: "number", unsigned: true })
      .notNull()
      .references(() => orders.id, { onDelete: "cascade" }),
    productId: bigint("productId", { mode: "number", unsigned: true }).references(
      () => products.id,
      { onDelete: "set null" },
    ),
    productName: varchar("productName", { length: 160 }).notNull(),
    unitPrice: int("unitPrice").notNull(),
    quantity: int("quantity").notNull(),
  },
  (table) => ({ orderIdx: index("order_items_order_idx").on(table.orderId) }),
);

export type User = typeof users.$inferSelect;
export type Product = typeof products.$inferSelect;
export type Order = typeof orders.$inferSelect;
export type OrderItem = typeof orderItems.$inferSelect;
