import { Routes, Route, Link } from "react-router";
import { Toaster } from "sonner";
import { Layout } from "@/components/Layout";
import { ShopProvider } from "@/store/ShopContext";
import Home from "@/pages/Home";
import MenuPage from "@/pages/MenuPage";
import OrdersPage from "@/pages/OrdersPage";
import AdminPage from "@/pages/AdminPage";

function NotFound() {
  return <section className="auth-required"><span className="mini-label">Error 404</span><h1>Esta mesa no existe</h1><p>La página que buscas no está disponible.</p><Link to="/" className="primary-button">Volver al inicio</Link></section>;
}

export default function App() {
  return (
    <ShopProvider>
      <Layout>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/menu" element={<MenuPage />} />
          <Route path="/pedidos" element={<OrdersPage />} />
          <Route path="/admin" element={<AdminPage />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
      </Layout>
      <Toaster position="bottom-center" richColors closeButton />
    </ShopProvider>
  );
}
