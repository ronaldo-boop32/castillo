import { useEffect } from "react";
import { Link, useLocation } from "react-router";
import { ArrowDownRight, ArrowRight, Clock3, MapPin, UtensilsCrossed } from "lucide-react";
import { ProductCard } from "@/components/ProductCard";
import { useShop } from "@/store/ShopContext";

export default function Home() {
  const { products, productsLoading } = useShop();
  const location = useLocation();
  const featured = products.filter((product) => product.featured).slice(0, 8);

  useEffect(() => {
    if (location.hash === "#nosotros") document.getElementById("nosotros")?.scrollIntoView();
  }, [location.hash]);

  return (
    <>
      <section className="home-hero">
        <div className="hero-grid-lines" aria-hidden="true" />
        <div className="hero-copy">
          <span className="mini-label">Barranquilla · Cocina para compartir</span>
          <h1>El sabor de aquí,<br /><em>como te gusta.</em></h1>
          <p>Platos costeños, antojos de siempre y algo dulce para terminar. Pide tu favorito y nosotros lo llevamos.</p>
          <div className="hero-actions">
            <Link to="/menu" className="primary-button">Quiero pedir <ArrowRight size={19} /></Link>
            <a href="#favoritos" className="underlined-link">Ver favoritos <ArrowDownRight size={18} /></a>
          </div>
          <div className="hero-meta">
            <span><Clock3 size={17} /> 30–45 min</span>
            <span><MapPin size={17} /> Barranquilla</span>
            <span><UtensilsCrossed size={17} /> 60 opciones</span>
          </div>
        </div>
        <div className="hero-visual">
          <div className="hero-photo-main"><img src="/images/reales/mojarra-frita.webp" alt="Mojarra frita con arroz y patacones" /></div>
          <div className="hero-photo-small"><img src="/images/reales/bandeja-paisa.webp" alt="Bandeja paisa" /></div>
          <div className="hero-stamp" aria-hidden="true"><span>SAZÓN · CARIBE · CASA · </span><strong>60</strong><small>sabores</small></div>
        </div>
      </section>

      <section className="category-ribbon" aria-label="Categorías principales">
        <Link to="/menu?categoria=colombiana"><span>01</span> Costeña <ArrowRight size={18} /></Link>
        <Link to="/menu?categoria=mariscos"><span>02</span> Mariscos <ArrowRight size={18} /></Link>
        <Link to="/menu?categoria=rapidas"><span>03</span> Antojos <ArrowRight size={18} /></Link>
        <Link to="/menu?categoria=postres"><span>04</span> Dulces <ArrowRight size={18} /></Link>
        <Link to="/menu?categoria=cocteles"><span>05</span> Cócteles <ArrowRight size={18} /></Link>
      </section>

      <section className="featured-section" id="favoritos">
        <div className="section-heading split-heading">
          <div><span className="mini-label">Los que más se repiten</span><h2>Favoritos de la casa</h2></div>
          <Link to="/menu" className="underlined-link">Ver los 60 productos <ArrowRight size={18} /></Link>
        </div>
        {productsLoading ? (
          <div className="loading-grid">{Array.from({ length: 4 }, (_, index) => <div className="product-skeleton" key={index} />)}</div>
        ) : (
          <div className="product-grid featured-grid">{featured.map((product, index) => <ProductCard key={product.id} product={product} priority={index < 4} />)}</div>
        )}
      </section>

      <section className="story-section" id="nosotros">
        <div className="story-images">
          <img className="story-large" src="/images/unsplash/foto-47.webp" alt="Plato servido en restaurante" loading="lazy" />
          <img className="story-small" src="/images/reales/arepa-huevo.webp" alt="Arepa de huevo costeña" loading="lazy" />
        </div>
        <div className="story-copy">
          <span className="mini-label">De la cocina a tu puerta</span>
          <h2>Aquí el hambre<br />se atiende con cariño.</h2>
          <p>Reunimos los sabores que se sienten como casa: recetas costeñas, mariscos, parrilla y esos antojos que nunca fallan.</p>
          <p>Cada pedido queda registrado para que puedas seguirlo. Sin pagos en línea, sin enredos: pides, confirmamos y disfrutas.</p>
          <Link to="/menu" className="underlined-link">Encontrar mi próximo plato <ArrowRight size={18} /></Link>
        </div>
      </section>

      <section className="discover-section">
        <div className="section-heading"><span className="mini-label">Para cada momento</span><h2>¿Qué se te antoja hoy?</h2></div>
        <div className="discover-grid">
          <Link to="/menu?categoria=helados" className="discover-card">
            <img src="/images/unsplash/foto-24.webp" alt="Helados artesanales" loading="lazy" />
            <div><span>Frescos y cremosos</span><h3>Helados</h3><ArrowRight /></div>
          </Link>
          <Link to="/menu?categoria=bebidas" className="discover-card tall-card">
            <img src="/images/unsplash/foto-25.webp" alt="Bebidas frías" loading="lazy" />
            <div><span>Para refrescar el día</span><h3>Bebidas</h3><ArrowRight /></div>
          </Link>
          <Link to="/menu?categoria=cocteles" className="discover-card">
            <img src="/images/reales/mojito-clasico.webp" alt="Mojitos con hierbabuena" loading="lazy" />
            <div><span>La tarde pide una copa</span><h3>Cócteles</h3><ArrowRight /></div>
          </Link>
          <Link to="/menu?categoria=postres" className="discover-card wide-card">
            <img src="/images/unsplash/foto-18.webp" alt="Torta de chocolate" loading="lazy" />
            <div><span>Un final bien dulce</span><h3>Postres</h3><ArrowRight /></div>
          </Link>
        </div>
      </section>
    </>
  );
}
