import { useMemo, useState } from "react";
import { Search, SlidersHorizontal, X } from "lucide-react";
import { useSearchParams } from "react-router";
import { CATEGORIES, CATEGORY_LABELS, type Category } from "@contracts/catalog";
import { ProductCard } from "@/components/ProductCard";
import { useShop } from "@/store/ShopContext";

const normalize = (text: string) => text.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase();

export default function MenuPage() {
  const { products, productsLoading } = useShop();
  const [params, setParams] = useSearchParams();
  const initialCategory = params.get("categoria");
  const [category, setCategory] = useState<Category | "todos">(
    CATEGORIES.includes(initialCategory as Category) ? initialCategory as Category : "todos",
  );
  const [query, setQuery] = useState("");
  const [sort, setSort] = useState("relevancia");

  const filtered = useMemo(() => {
    const result = products.filter((product) => {
      const inCategory = category === "todos" || product.category === category;
      const searchText = normalize(`${product.name} ${product.description}`);
      return inCategory && searchText.includes(normalize(query));
    });
    if (sort === "menor") return [...result].sort((a, b) => a.price - b.price);
    if (sort === "mayor") return [...result].sort((a, b) => b.price - a.price);
    if (sort === "nombre") return [...result].sort((a, b) => a.name.localeCompare(b.name));
    return result;
  }, [products, category, query, sort]);

  const chooseCategory = (value: Category | "todos") => {
    setCategory(value);
    setParams(value === "todos" ? {} : { categoria: value });
  };

  return (
    <div className="menu-page">
      <section className="menu-intro">
        <span className="mini-label">La carta completa</span>
        <h1>Pide lo que<br /><em>te provoque.</em></h1>
        <p>Del sancocho al mojito. Explora las categorías, encuentra tu antojo y agrégalo al carrito.</p>
      </section>

      <section className="catalog-section">
        <div className="catalog-tools">
          <label className="search-box"><Search size={20} /><input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Buscar un plato, sabor o ingrediente…" aria-label="Buscar productos" />{query && <button onClick={() => setQuery("")} aria-label="Borrar búsqueda"><X size={17} /></button>}</label>
          <label className="sort-box"><SlidersHorizontal size={18} /><span>Ordenar</span><select value={sort} onChange={(e) => setSort(e.target.value)}><option value="relevancia">Relevancia</option><option value="menor">Precio: menor a mayor</option><option value="mayor">Precio: mayor a menor</option><option value="nombre">Nombre A–Z</option></select></label>
        </div>
        <div className="category-chips" aria-label="Filtrar por categoría">
          <button className={category === "todos" ? "active" : ""} onClick={() => chooseCategory("todos")}>Todo <span>{products.length}</span></button>
          {CATEGORIES.map((item) => <button key={item} className={category === item ? "active" : ""} onClick={() => chooseCategory(item)}>{CATEGORY_LABELS[item]} <span>{products.filter((product) => product.category === item).length}</span></button>)}
        </div>

        <div className="catalog-count"><strong>{filtered.length}</strong> {filtered.length === 1 ? "opción encontrada" : "opciones encontradas"}</div>
        {productsLoading ? (
          <div className="loading-grid">{Array.from({ length: 8 }, (_, index) => <div className="product-skeleton" key={index} />)}</div>
        ) : filtered.length ? (
          <div className="product-grid catalog-grid">{filtered.map((product, index) => <ProductCard key={product.id} product={product} priority={index < 4} />)}</div>
        ) : (
          <div className="empty-results"><Search size={38} strokeWidth={1.3} /><h2>No encontramos ese antojo</h2><p>Prueba otra palabra o vuelve a ver todo el menú.</p><button className="primary-button" onClick={() => { setQuery(""); chooseCategory("todos"); }}>Ver todo el menú</button></div>
        )}
      </section>
    </div>
  );
}
