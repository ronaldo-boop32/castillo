import { useState, type FormEvent } from "react";
import { Link } from "react-router";
import { CircleDollarSign, ClipboardList, Edit3, Package, Plus, Search, ShieldAlert, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { CATEGORIES, CATEGORY_LABELS, type Category } from "@contracts/catalog";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { trpc, type RouterOutputs } from "@/providers/trpc";
import { money, useShop } from "@/store/ShopContext";

type AdminData = RouterOutputs["shop"]["adminOverview"];
type AdminProduct = AdminData["products"][number];
type ProductForm = {
  slug: string;
  name: string;
  description: string;
  category: Category;
  price: number;
  image: string;
  featured: boolean;
  available: boolean;
};

const emptyProduct: ProductForm = {
  slug: "", name: "", description: "", category: "colombiana", price: 0,
  image: "/images/reales/bandeja-paisa.webp", featured: false, available: true,
};
const slugify = (text: string) => text.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "");
const statusLabels = { pendiente: "Recibido", preparando: "En cocina", en_camino: "En camino", entregado: "Entregado", cancelado: "Cancelado" };

export default function AdminPage() {
  const { user, userLoading } = useShop();
  const utils = trpc.useUtils();
  const overview = trpc.shop.adminOverview.useQuery(undefined, { enabled: user?.role === "admin", retry: false });
  const [tab, setTab] = useState<"orders" | "products">("orders");
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editing, setEditing] = useState<AdminProduct | null>(null);
  const [form, setForm] = useState<ProductForm>(emptyProduct);
  const [formError, setFormError] = useState("");
  const [query, setQuery] = useState("");

  const refresh = () => {
    void utils.shop.adminOverview.invalidate();
    void utils.shop.products.invalidate();
  };
  const onMutationError = (error: { message: string }) => setFormError(error.message);
  const createProduct = trpc.shop.createProduct.useMutation({ onSuccess: () => { refresh(); setDialogOpen(false); toast.success("Producto creado"); }, onError: onMutationError });
  const updateProduct = trpc.shop.updateProduct.useMutation({ onSuccess: () => { refresh(); setDialogOpen(false); toast.success("Producto actualizado"); }, onError: onMutationError });
  const deleteProduct = trpc.shop.deleteProduct.useMutation({ onSuccess: () => { refresh(); toast.success("Producto eliminado"); }, onError: (error) => toast.error(error.message) });
  const updateStatus = trpc.shop.updateOrderStatus.useMutation({ onSuccess: () => { refresh(); toast.success("Estado actualizado"); }, onError: (error) => toast.error(error.message) });

  if (userLoading) return <div className="page-loading"><span className="loader" /><p>Comprobando acceso…</p></div>;
  if (user?.role !== "admin") return (
    <section className="auth-required"><ShieldAlert size={44} strokeWidth={1.2} /><span className="mini-label">Acceso restringido</span><h1>Este espacio es de Juan</h1><p>Inicia sesión con la cuenta de administrador para gestionar la tienda.</p><Link className="primary-button" to="/">Volver a la tienda</Link></section>
  );

  const openCreate = () => { setEditing(null); setForm(emptyProduct); setFormError(""); setDialogOpen(true); };
  const openEdit = (product: AdminProduct) => {
    setEditing(product);
    setForm({ slug: product.slug, name: product.name, description: product.description, category: product.category, price: product.price, image: product.image, featured: product.featured, available: product.available });
    setFormError("");
    setDialogOpen(true);
  };
  const submitProduct = (event: FormEvent) => {
    event.preventDefault();
    setFormError("");
    if (editing) updateProduct.mutate({ ...form, id: editing.id });
    else createProduct.mutate(form);
  };

  const data = overview.data;
  const visibleProducts = data?.products.filter((product) => `${product.name} ${product.category}`.toLowerCase().includes(query.toLowerCase())) ?? [];

  return (
    <div className="admin-page">
      <section className="admin-heading"><div><span className="mini-label">Panel de administración</span><h1>Hola, Juan.</h1><p>Gestiona la carta y mantén cada pedido al día.</p></div><button className="primary-button" onClick={openCreate}><Plus size={18} /> Nuevo producto</button></section>

      {overview.isLoading ? <div className="page-loading"><span className="loader" /><p>Cargando el negocio…</p></div> : overview.error ? <div className="empty-results"><h2>No pudimos cargar el panel</h2><p>{overview.error.message}</p><button className="primary-button" onClick={() => overview.refetch()}>Reintentar</button></div> : data && (
        <>
          <div className="stats-grid">
            <div><CircleDollarSign /><span>Ventas registradas</span><strong>{money(data.stats.sales)}</strong></div>
            <div><ClipboardList /><span>Pedidos por confirmar</span><strong>{data.stats.pending}</strong></div>
            <div><Package /><span>Productos en carta</span><strong>{data.stats.products}</strong></div>
            <div><ClipboardList /><span>Pedidos totales</span><strong>{data.stats.orders}</strong></div>
          </div>
          <div className="admin-tabs"><button className={tab === "orders" ? "active" : ""} onClick={() => setTab("orders")}>Pedidos <span>{data.orders.length}</span></button><button className={tab === "products" ? "active" : ""} onClick={() => setTab("products")}>Productos <span>{data.products.length}</span></button></div>

          {tab === "orders" ? (
            <section className="admin-orders">
              {data.orders.length ? data.orders.map((order) => (
                <article className="admin-order" key={order.id}>
                  <div className="admin-order-id"><strong>#{String(order.id).padStart(4, "0")}</strong><span>{new Intl.DateTimeFormat("es-CO", { day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit" }).format(order.createdAt)}</span></div>
                  <div className="admin-order-customer"><strong>{order.customerName}</strong><span>{order.phone}</span><p>{order.address}</p></div>
                  <div className="admin-order-items">{order.items.map((item) => <span key={item.id}>{item.quantity}× {item.productName}</span>)}{order.notes && <p>Nota: {order.notes}</p>}</div>
                  <strong className="admin-order-total">{money(order.total)}</strong>
                  <label className="status-select"><span className="sr-only">Estado del pedido {order.id}</span><select value={order.status} disabled={updateStatus.isPending} onChange={(e) => updateStatus.mutate({ id: order.id, status: e.target.value as keyof typeof statusLabels })}>{Object.entries(statusLabels).map(([value, label]) => <option value={value} key={value}>{label}</option>)}</select></label>
                </article>
              )) : <div className="empty-results"><ClipboardList size={40} /><h2>Aún no hay pedidos</h2><p>Cuando un cliente confirme una compra aparecerá aquí.</p></div>}
            </section>
          ) : (
            <section className="admin-products">
              <label className="search-box admin-search"><Search size={19} /><input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Buscar en el catálogo…" /></label>
              <div className="admin-product-table">
                <div className="admin-product-row table-head"><span>Producto</span><span>Categoría</span><span>Precio</span><span>Estado</span><span>Acciones</span></div>
                {visibleProducts.map((product) => (
                  <div className="admin-product-row" key={product.id}>
                    <div className="admin-product-name"><img src={product.image} alt="" /><div><strong>{product.name}</strong><span>{product.slug}</span></div></div>
                    <span>{CATEGORY_LABELS[product.category]}</span>
                    <strong>{money(product.price)}</strong>
                    <span className={product.available ? "available-dot" : "unavailable-dot"}>{product.available ? "Disponible" : "Oculto"}</span>
                    <div className="row-actions"><button onClick={() => openEdit(product)} aria-label={`Editar ${product.name}`}><Edit3 size={17} /></button><button className="danger-action" onClick={() => { if (window.confirm(`¿Eliminar ${product.name}? Los pedidos anteriores conservarán su información.`)) deleteProduct.mutate({ id: product.id }); }} aria-label={`Eliminar ${product.name}`}><Trash2 size={17} /></button></div>
                  </div>
                ))}
              </div>
            </section>
          )}
        </>
      )}

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="product-dialog">
          <DialogHeader><span className="mini-label">Catálogo</span><DialogTitle>{editing ? "Editar producto" : "Nuevo producto"}</DialogTitle><DialogDescription>Completa la información que verán los clientes.</DialogDescription></DialogHeader>
          <form className="stack-form" onSubmit={submitProduct}>
            <div className="form-two-cols">
              <label>Nombre<input required minLength={2} value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value, slug: editing ? form.slug : slugify(e.target.value) })} /></label>
              <label>Identificador (slug)<input required pattern="[a-z0-9-]+" value={form.slug} onChange={(e) => setForm({ ...form, slug: e.target.value })} /></label>
            </div>
            <label>Descripción<textarea required minLength={10} rows={3} value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} /></label>
            <div className="form-two-cols">
              <label>Categoría<select value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value as Category })}>{CATEGORIES.map((category) => <option value={category} key={category}>{CATEGORY_LABELS[category]}</option>)}</select></label>
              <label>Precio COP<input required type="number" min={0} step={100} value={form.price} onChange={(e) => setForm({ ...form, price: Number(e.target.value) })} /></label>
            </div>
            <label>Ruta o URL de la fotografía<input required value={form.image} onChange={(e) => setForm({ ...form, image: e.target.value })} /></label>
            <div className="form-checks"><label><input type="checkbox" checked={form.featured} onChange={(e) => setForm({ ...form, featured: e.target.checked })} /> Destacar en inicio</label><label><input type="checkbox" checked={form.available} onChange={(e) => setForm({ ...form, available: e.target.checked })} /> Disponible para pedir</label></div>
            {formError && <p className="form-error" role="alert">{formError}</p>}
            <button className="primary-button full-button" disabled={createProduct.isPending || updateProduct.isPending} type="submit">{createProduct.isPending || updateProduct.isPending ? "Guardando…" : editing ? "Guardar cambios" : "Crear producto"}</button>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
