import { ArrowRight, PackageOpen, RotateCcw, UserRound } from "lucide-react";
import { Link } from "react-router";
import { trpc } from "@/providers/trpc";
import { money, useShop } from "@/store/ShopContext";

const STATUS = {
  pendiente: { label: "Recibido", text: "Estamos confirmando tu pedido." },
  preparando: { label: "En cocina", text: "Ya estamos preparando tus platos." },
  en_camino: { label: "En camino", text: "Tu pedido va en camino." },
  entregado: { label: "Entregado", text: "Este pedido ya fue entregado." },
  cancelado: { label: "Cancelado", text: "Este pedido fue cancelado." },
};

export default function OrdersPage() {
  const { user, userLoading, setAuthOpen, addToCart, setCartOpen, products } = useShop();
  const ordersQuery = trpc.shop.myOrders.useQuery(undefined, { enabled: !!user, retry: false });

  if (userLoading) return <div className="page-loading"><span className="loader" /><p>Cargando tu cuenta…</p></div>;
  if (!user) return (
    <section className="auth-required">
      <UserRound size={42} strokeWidth={1.2} />
      <span className="mini-label">Tu historial, en un solo lugar</span>
      <h1>Entra para ver tus pedidos</h1>
      <p>Inicia sesión o crea una cuenta para consultar estados y volver a pedir tus favoritos.</p>
      <button className="primary-button" onClick={() => setAuthOpen(true)}>Entrar o registrarme <ArrowRight size={18} /></button>
    </section>
  );

  const reorder = (items: Array<{ productId: number | null; quantity: number }>) => {
    let added = 0;
    items.forEach((item) => {
      if (item.productId && products.some((product) => product.id === item.productId && product.available)) {
        for (let index = 0; index < item.quantity; index += 1) addToCart(item.productId);
        added += 1;
      }
    });
    if (added) setCartOpen(true);
  };

  return (
    <div className="orders-page">
      <section className="account-heading">
        <div><span className="mini-label">Hola, {user.name}</span><h1>Mis pedidos</h1><p>Aquí puedes ver el estado de cada compra y repetir tus favoritos.</p></div>
        <Link to="/menu" className="primary-button">Hacer otro pedido <ArrowRight size={18} /></Link>
      </section>

      {ordersQuery.isLoading ? <div className="page-loading"><span className="loader" /><p>Buscando tus pedidos…</p></div> : ordersQuery.error ? (
        <div className="empty-results"><h2>No pudimos cargar el historial</h2><p>{ordersQuery.error.message}</p><button className="primary-button" onClick={() => ordersQuery.refetch()}>Intentar de nuevo</button></div>
      ) : ordersQuery.data?.length ? (
        <div className="orders-list">
          {ordersQuery.data.map((order) => (
            <article className="order-card" key={order.id}>
              <div className="order-card-top">
                <div><span>Pedido</span><h2>#{String(order.id).padStart(4, "0")}</h2></div>
                <div><span>Fecha</span><strong>{new Intl.DateTimeFormat("es-CO", { day: "numeric", month: "short", year: "numeric" }).format(order.createdAt)}</strong></div>
                <span className={`status-badge status-${order.status}`}>{STATUS[order.status].label}</span>
              </div>
              <p className="order-status-text">{STATUS[order.status].text}</p>
              <div className="order-items">
                {order.items.map((item) => <div key={item.id}><span><b>{item.quantity}×</b> {item.productName}</span><span>{money(item.unitPrice * item.quantity)}</span></div>)}
              </div>
              <div className="order-address"><span>Entrega en</span><p>{order.address}</p></div>
              <div className="order-card-bottom"><strong>Total {money(order.total)}</strong><button className="underlined-link" onClick={() => reorder(order.items)}><RotateCcw size={16} /> Repetir pedido</button></div>
            </article>
          ))}
        </div>
      ) : (
        <div className="empty-results"><PackageOpen size={42} strokeWidth={1.2} /><h2>Todavía no has pedido</h2><p>Tu próximo favorito puede ser el primero.</p><Link to="/menu" className="primary-button">Explorar el menú <ArrowRight size={18} /></Link></div>
      )}
    </div>
  );
}
