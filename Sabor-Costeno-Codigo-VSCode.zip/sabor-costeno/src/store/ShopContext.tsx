import { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import { toast } from "sonner";
import { trpc, type RouterOutputs } from "@/providers/trpc";

export type ShopProduct = RouterOutputs["shop"]["products"][number];
type CurrentUser = NonNullable<RouterOutputs["auth"]["me"]>;
type CartLine = { productId: number; quantity: number };
export type DetailedCartLine = CartLine & { product: ShopProduct };

type ShopContextValue = {
  products: ShopProduct[];
  productsLoading: boolean;
  user: CurrentUser | null;
  userLoading: boolean;
  cart: DetailedCartLine[];
  cartCount: number;
  cartTotal: number;
  cartOpen: boolean;
  authOpen: boolean;
  setCartOpen: (open: boolean) => void;
  setAuthOpen: (open: boolean) => void;
  addToCart: (productId: number) => void;
  updateQuantity: (productId: number, quantity: number) => void;
  clearCart: () => void;
  refreshUser: () => void;
};

const ShopContext = createContext<ShopContextValue | null>(null);

export function ShopProvider({ children }: { children: ReactNode }) {
  const utils = trpc.useUtils();
  const productsQuery = trpc.shop.products.useQuery();
  const meQuery = trpc.auth.me.useQuery(undefined, { retry: false });
  const [lines, setLines] = useState<CartLine[]>(() => {
    try {
      return JSON.parse(localStorage.getItem("sabor_cart") ?? "[]") as CartLine[];
    } catch {
      return [];
    }
  });
  const [cartOpen, setCartOpen] = useState(false);
  const [authOpen, setAuthOpen] = useState(false);

  useEffect(() => {
    localStorage.setItem("sabor_cart", JSON.stringify(lines));
  }, [lines]);

  const products = useMemo(() => productsQuery.data ?? [], [productsQuery.data]);
  const cart = useMemo(
    () => lines.flatMap((line) => {
      const product = products.find((item) => item.id === line.productId);
      return product ? [{ ...line, product }] : [];
    }),
    [lines, products],
  );

  const addToCart = (productId: number) => {
    setLines((current) => {
      const found = current.find((line) => line.productId === productId);
      if (found) return current.map((line) => line.productId === productId ? { ...line, quantity: Math.min(30, line.quantity + 1) } : line);
      return [...current, { productId, quantity: 1 }];
    });
    const product = products.find((item) => item.id === productId);
    toast.success(`${product?.name ?? "Producto"} añadido al carrito`);
  };

  const updateQuantity = (productId: number, quantity: number) => {
    setLines((current) => quantity <= 0
      ? current.filter((line) => line.productId !== productId)
      : current.map((line) => line.productId === productId ? { ...line, quantity: Math.min(30, quantity) } : line));
  };

  const value: ShopContextValue = {
    products,
    productsLoading: productsQuery.isLoading,
    user: meQuery.data ?? null,
    userLoading: meQuery.isLoading,
    cart,
    cartCount: lines.reduce((sum, line) => sum + line.quantity, 0),
    cartTotal: cart.reduce((sum, line) => sum + line.product.price * line.quantity, 0),
    cartOpen,
    authOpen,
    setCartOpen,
    setAuthOpen,
    addToCart,
    updateQuantity,
    clearCart: () => setLines([]),
    refreshUser: () => { void utils.auth.me.invalidate(); },
  };

  return <ShopContext.Provider value={value}>{children}</ShopContext.Provider>;
}

export function useShop() {
  const context = useContext(ShopContext);
  if (!context) throw new Error("useShop debe usarse dentro de ShopProvider");
  return context;
}

export const money = (value: number) => new Intl.NumberFormat("es-CO", {
  style: "currency",
  currency: "COP",
  maximumFractionDigits: 0,
}).format(value);
