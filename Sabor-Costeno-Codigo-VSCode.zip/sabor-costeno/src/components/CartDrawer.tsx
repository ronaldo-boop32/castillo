import { useState, type FormEvent } from "react";
import { Link } from "react-router";
import { ArrowRight, Check, Minus, Plus, ShoppingBag, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { trpc } from "@/providers/trpc";
import { money, useShop } from "@/store/ShopContext";

export function CartDrawer() {
  const { cart, cartTotal, cartOpen, setCartOpen, updateQuantity, clearCart, user, setAuthOpen } = useShop();
  const [step, setStep] = useState<"cart" | "checkout" | "success">("cart");
  const [orderId, setOrderId] = useState<number | null>(null);
  const [form, setForm] = useState({ customerName: user?.name ?? "", phone: "", address: "", notes: "" });
  const [error, setError] = useState("");

  const createOrder = trpc.shop.createOrder.useMutation({
    onSuccess: (result) => {
      setOrderId(result.id);
      setStep("success");
      clearCart();
      toast.success("Pedido recibido");
    },
    onError: (err) => setError(err.message),
  });

  const submitOrder = (event: FormEvent) => {
    event.preventDefault();
    setError("");
    if (!user) {
      setCartOpen(false);
      setAuthOpen(true);
      toast.info("Inicia sesión para terminar tu pedido");
      return;
    }
    createOrder.mutate({
      ...form,
      items: cart.map((line) => ({ productId: line.productId, quantity: line.quantity })),
    });
  };

  return (
    <Sheet open={cartOpen} onOpenChange={(open) => { setCartOpen(open); if (open && step === "success") setStep("cart"); }}>
      <SheetContent className="cart-drawer">
        <SheetHeader>
          <span className="mini-label">Tu pedido</span>
          <SheetTitle>{step === "success" ? "Ya estamos en eso" : step === "checkout" ? "¿Dónde te lo llevamos?" : "Tu carrito"}</SheetTitle>
          <SheetDescription>
            {step === "cart" ? "Revisa cantidades y confirma tu compra." : step === "checkout" ? "Completa los datos de entrega." : "Recibimos tu pedido correctamente."}
          </SheetDescription>
        </SheetHeader>

        {step === "success" ? (
          <div className="order-success">
            <span className="success-icon"><Check size={30} /></span>
            <h3>Pedido #{String(orderId).padStart(4, "0")}</h3>
            <p>Juan y el equipo ya pueden verlo. Te contactaremos al número registrado para confirmar la entrega.</p>
            <Link className="primary-button full-button" to="/pedidos" onClick={() => setCartOpen(false)}>Ver mi pedido <ArrowRight size={18} /></Link>
            <button className="text-link" onClick={() => { setStep("cart"); setCartOpen(false); }}>Seguir explorando</button>
          </div>
        ) : cart.length === 0 ? (
          <div className="empty-cart">
            <ShoppingBag size={40} strokeWidth={1.4} />
            <h3>Tu carrito está esperando sabor</h3>
            <p>Agrega un plato del menú y aparecerá aquí.</p>
            <Link to="/menu" className="primary-button" onClick={() => setCartOpen(false)}>Explorar el menú <ArrowRight size={18} /></Link>
          </div>
        ) : step === "cart" ? (
          <>
            <div className="cart-lines">
              {cart.map((line) => (
                <article className="cart-line" key={line.productId}>
                  <img src={line.product.image} alt={line.product.name} />
                  <div className="cart-line-info">
                    <h3>{line.product.name}</h3>
                    <strong>{money(line.product.price * line.quantity)}</strong>
                    <div className="quantity-control" aria-label={`Cantidad de ${line.product.name}`}>
                      <button onClick={() => updateQuantity(line.productId, line.quantity - 1)} aria-label="Restar uno"><Minus size={15} /></button>
                      <span>{line.quantity}</span>
                      <button onClick={() => updateQuantity(line.productId, line.quantity + 1)} aria-label="Sumar uno"><Plus size={15} /></button>
                    </div>
                  </div>
                  <button className="remove-line" onClick={() => updateQuantity(line.productId, 0)} aria-label={`Quitar ${line.product.name}`}><Trash2 size={17} /></button>
                </article>
              ))}
            </div>
            <div className="cart-summary">
              <div><span>Subtotal</span><strong>{money(cartTotal)}</strong></div>
              <div><span>Domicilio</span><strong>Gratis</strong></div>
              <div className="summary-total"><span>Total</span><strong>{money(cartTotal)}</strong></div>
              <button className="primary-button full-button" onClick={() => setStep("checkout")}>Continuar pedido <ArrowRight size={18} /></button>
              <button className="text-link" onClick={clearCart}>Vaciar carrito</button>
            </div>
          </>
        ) : (
          <form className="stack-form checkout-form" onSubmit={submitOrder}>
            <button className="text-link back-link" type="button" onClick={() => setStep("cart")}>← Volver al carrito</button>
            <label>Nombre de quien recibe
              <input required minLength={2} value={form.customerName} onChange={(e) => setForm({ ...form, customerName: e.target.value })} autoComplete="name" />
            </label>
            <label>Teléfono
              <input required minLength={7} type="tel" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} placeholder="300 000 0000" autoComplete="tel" />
            </label>
            <label>Dirección en Barranquilla
              <input required minLength={5} value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} placeholder="Barrio, calle, carrera y número" autoComplete="street-address" />
            </label>
            <label>Notas <small>(opcional)</small>
              <textarea value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} placeholder="Apartamento, referencia o indicaciones" maxLength={500} rows={3} />
            </label>
            <div className="checkout-total"><span>Total a pagar contra entrega</span><strong>{money(cartTotal)}</strong></div>
            {error && <p className="form-error" role="alert">{error}</p>}
            <button className="primary-button full-button" disabled={createOrder.isPending} type="submit">
              {createOrder.isPending ? "Enviando pedido…" : "Confirmar pedido"} <ArrowRight size={18} />
            </button>
            <p className="privacy-note">Pago contra entrega. No necesitas ingresar datos bancarios.</p>
          </form>
        )}
      </SheetContent>
    </Sheet>
  );
}
