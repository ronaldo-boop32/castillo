import { useState, type FormEvent } from "react";
import { ArrowRight, Eye, EyeOff } from "lucide-react";
import { toast } from "sonner";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { trpc } from "@/providers/trpc";
import { useShop } from "@/store/ShopContext";

export function AuthDialog() {
  const { authOpen, setAuthOpen, refreshUser } = useShop();
  const [mode, setMode] = useState<"login" | "register">("login");
  const [showPassword, setShowPassword] = useState(false);
  const [form, setForm] = useState({ name: "", email: "", password: "" });
  const [error, setError] = useState("");

  const onSuccess = () => {
    refreshUser();
    setAuthOpen(false);
    setError("");
    setForm({ name: "", email: "", password: "" });
    toast.success(mode === "login" ? "Qué bueno verte de nuevo" : "Tu cuenta está lista");
  };
  const onError = (err: { message: string }) => setError(err.message);
  const login = trpc.auth.login.useMutation({ onSuccess, onError });
  const register = trpc.auth.register.useMutation({ onSuccess, onError });
  const pending = login.isPending || register.isPending;

  const submit = (event: FormEvent) => {
    event.preventDefault();
    setError("");
    if (mode === "login") login.mutate({ email: form.email, password: form.password });
    else register.mutate(form);
  };

  return (
    <Dialog open={authOpen} onOpenChange={setAuthOpen}>
      <DialogContent className="auth-dialog">
        <DialogHeader>
          <span className="mini-label">Tu mesa te espera</span>
          <DialogTitle>{mode === "login" ? "Entra a Sabor Costeño" : "Crea tu cuenta"}</DialogTitle>
          <DialogDescription>
            {mode === "login" ? "Inicia sesión para pedir y ver tu historial." : "Regístrate en menos de un minuto para hacer tu primer pedido."}
          </DialogDescription>
        </DialogHeader>
        <div className="auth-tabs" role="tablist" aria-label="Acceso de usuarios">
          <button role="tab" aria-selected={mode === "login"} className={mode === "login" ? "active" : ""} onClick={() => { setMode("login"); setError(""); }}>Entrar</button>
          <button role="tab" aria-selected={mode === "register"} className={mode === "register" ? "active" : ""} onClick={() => { setMode("register"); setError(""); }}>Registrarme</button>
        </div>
        <form className="stack-form" onSubmit={submit}>
          {mode === "register" && (
            <label>Nombre completo
              <input required minLength={2} maxLength={120} value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="¿Cómo te llamas?" autoComplete="name" />
            </label>
          )}
          <label>Correo electrónico
            <input required type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} placeholder="tu@correo.com" autoComplete="email" />
          </label>
          <label>Contraseña
            <span className="password-field">
              <input required type={showPassword ? "text" : "password"} minLength={8} value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} placeholder="Mínimo 8 caracteres" autoComplete={mode === "login" ? "current-password" : "new-password"} />
              <button type="button" onClick={() => setShowPassword(!showPassword)} aria-label={showPassword ? "Ocultar contraseña" : "Mostrar contraseña"}>
                {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
              </button>
            </span>
          </label>
          {error && <p className="form-error" role="alert">{error}</p>}
          <button className="primary-button full-button" disabled={pending} type="submit">
            {pending ? "Un momento…" : mode === "login" ? "Entrar" : "Crear mi cuenta"} <ArrowRight size={18} />
          </button>
        </form>
        <p className="privacy-note">Tus datos se usan únicamente para gestionar tu cuenta y tus pedidos.</p>
      </DialogContent>
    </Dialog>
  );
}
