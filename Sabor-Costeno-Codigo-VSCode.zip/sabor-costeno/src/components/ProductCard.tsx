import { Plus } from "lucide-react";
import { CATEGORY_LABELS } from "@contracts/catalog";
import { money, useShop, type ShopProduct } from "@/store/ShopContext";

export function ProductCard({ product, priority = false }: { product: ShopProduct; priority?: boolean }) {
  const { addToCart } = useShop();
  return (
    <article className={`product-card ${!product.available ? "unavailable" : ""}`}>
      <div className="product-image-wrap">
        <img src={product.image} alt={`Fotografía de ${product.name}`} loading={priority ? "eager" : "lazy"} />
        {product.featured && <span className="favorite-tag">De la casa</span>}
        {!product.available && <span className="sold-out">Agotado</span>}
      </div>
      <div className="product-copy">
        <span className="product-category">{CATEGORY_LABELS[product.category]}</span>
        <h3>{product.name}</h3>
        <p>{product.description}</p>
        <div className="product-bottom">
          <strong>{money(product.price)}</strong>
          <button onClick={() => addToCart(product.id)} disabled={!product.available} aria-label={`Añadir ${product.name} al carrito`}>
            <Plus size={18} /> <span>Añadir</span>
          </button>
        </div>
      </div>
    </article>
  );
}
