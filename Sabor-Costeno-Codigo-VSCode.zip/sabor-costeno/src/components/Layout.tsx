import { useState, type ReactNode } from "react";
import { Link, NavLink, useLocation } from "react-router";
import { LogOut, Menu, ShoppingBag, UserRound, X } from "lucide-react";
import { trpc } from "@/providers/trpc";
import { useShop } from "@/store/ShopContext";
import { AuthDialog } from "./AuthDialog";
import { CartDrawer } from "./CartDrawer";

function Wordmark() {
  return (
    <Link to="/" className="wordmark" aria-label="Sabor Costeño, inicio">
      <span className="wordmark-sun" aria-hidden="true" />
      <span>Sabor<br /><strong>Costeño</strong></span>
    </Link>
  );
}

export function Layout({ children }: { children: ReactNode }) {
  const { user, cartCount, setCartOpen, setAuthOpen, refreshUser } = useShop();
  const [menuOpen, setMenuOpen] = useState(false);
  const location = useLocation();
  const logout = trpc.auth.logout.useMutation({ onSuccess: refreshUser });

  const closeMenu = () => setMenuOpen(false);

  return (
    <div className="site-shell">
      <header className="site-header">
        <Wordmark />
        <nav className="desktop-nav" aria-label="Navegación principal">
          <NavLink to="/">Inicio</NavLink>
          <NavLink to="/menu">Menú</NavLink>
          <NavLink to="/pedidos">Mis pedidos</NavLink>
          {user?.role === "admin" && <NavLink to="/admin">Administración</NavLink>}
        </nav>
        <div className="header-actions">
          {user ? (
            <div className="user-chip">
              <span><small>Hola</small>{user.name}</span>
              <button className="icon-button" onClick={() => logout.mutate()} aria-label="Cerrar sesión" title="Cerrar sesión">
                <LogOut size={18} />
              </button>
            </div>
          ) : (
            <button className="text-button login-button" onClick={() => setAuthOpen(true)}>
              <UserRound size={18} /> <span>Entrar</span>
            </button>
          )}
          <button className="cart-button" onClick={() => setCartOpen(true)} aria-label={`Abrir carrito con ${cartCount} productos`}>
            <ShoppingBag size={19} />
            <span>Carrito</span>
            <b>{cartCount}</b>
          </button>
          <button className="icon-button mobile-menu-button" onClick={() => setMenuOpen(!menuOpen)} aria-expanded={menuOpen} aria-label="Abrir menú">
            {menuOpen ? <X size={22} /> : <Menu size={22} />}
          </button>
        </div>
      </header>

      {menuOpen && (
        <nav className="mobile-nav" aria-label="Navegación móvil">
          <NavLink to="/" onClick={closeMenu}>Inicio</NavLink>
          <NavLink to="/menu" onClick={closeMenu}>Menú completo</NavLink>
          <NavLink to="/pedidos" onClick={closeMenu}>Mis pedidos</NavLink>
          {user?.role === "admin" && <NavLink to="/admin" onClick={closeMenu}>Administración</NavLink>}
          {!user && <button onClick={() => { closeMenu(); setAuthOpen(true); }}>Entrar o registrarme</button>}
        </nav>
      )}

      <main key={location.pathname}>{children}</main>

      <footer className="site-footer">
        <div className="footer-top">
          <div>
            <Wordmark />
            <p>Cocina de aquí, sabor que te queda.<br />Barranquilla, Colombia.</p>
          </div>
          <div className="footer-links">
            <strong>Explora</strong>
            <Link to="/menu">Menú completo</Link>
            <Link to="/pedidos">Seguir mi pedido</Link>
            <a href="mailto:hola@saborcosteno.com">hola@saborcosteno.com</a>
          </div>
          <div className="footer-hours">
            <strong>Hoy sí hay</strong>
            <p>Lunes a domingo<br />11:00 a. m. — 10:00 p. m.</p>
            <span>Domicilios en Barranquilla</span>
          </div>
        </div>
        <div className="footer-bottom">
          <span>© 2026 Sabor Costeño</span>
          <span>Hecho con sazón del Caribe</span>
        </div>
      </footer>
      <AuthDialog />
      <CartDrawer />
    </div>
  );
}
