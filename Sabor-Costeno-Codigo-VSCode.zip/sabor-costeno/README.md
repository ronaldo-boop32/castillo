# Sabor Costeño

Tienda gastronómica full-stack en español, con los 40 platos del catálogo de Barranquilla y 20 opciones adicionales de helados, bebidas, cócteles y postres.

## Funciones incluidas

- Catálogo de 60 productos con fotografías locales, búsqueda, filtros y ordenamiento.
- Registro, inicio y cierre de sesión con contraseñas cifradas y sesiones seguras.
- Carrito con cantidades, datos de entrega y pago contra entrega.
- Pedidos guardados en MySQL e historial para cada usuario.
- Panel de administración para Juan: métricas, estados de pedidos y gestión de productos.
- Diseño adaptable a teléfonos, tabletas y escritorio.
- Precios y disponibilidad validados nuevamente en el servidor al confirmar cada pedido.

## Requisitos

- Node.js 22.12 o superior.
- MySQL 8 o una base compatible con MySQL.
- Visual Studio Code.

## Ejecutar en VS Code

1. Descomprime el proyecto y abre la carpeta `sabor-costeno` en VS Code.
2. Abre una terminal en esa carpeta.
3. Crea la base de datos en MySQL:

   ```sql
   CREATE DATABASE sabor_costeno
     CHARACTER SET utf8mb4
     COLLATE utf8mb4_unicode_ci;
   ```

4. Copia `.env.example` como `.env` y edita `DATABASE_URL` con tu usuario y contraseña de MySQL:

   ```env
   APP_ID=sabor-costeno-local
   APP_SECRET=una-clave-larga-y-aleatoria
   DATABASE_URL=mysql://root:password@localhost:3306/sabor_costeno
   ```

5. Instala las dependencias, crea las tablas y carga el catálogo:

   ```bash
   npm install
   npm run db:push
   npm run db:seed
   npm run dev
   ```

6. Abre **http://localhost:3000**.

El seed puede ejecutarse de nuevo sin duplicar el catálogo. Ten en cuenta que restablece los datos originales de los productos sembrados y la contraseña de Juan.

## Cuenta de administrador

- **Correo:** `juan@saborcosteno.com`
- **Contraseña:** `Juan2026!`

Después de entrar, aparece el enlace **Administración** en la navegación. Cambia estas credenciales antes de usar el proyecto en un entorno real.

## Comandos

| Comando | Uso |
| --- | --- |
| `npm run dev` | Desarrollo en el puerto 3000 |
| `npm run check` | Comprobación de TypeScript |
| `npm run lint` | Revisión de calidad del código |
| `npm run build` | Compilación del frontend y del servidor |
| `npm start` | Ejecutar la compilación de producción |
| `npm run db:push` | Sincronizar el esquema con MySQL |
| `npm run db:seed` | Cargar los 60 productos y el administrador |

## Estructura principal

- `src/`: páginas, componentes, estilos y estado del carrito.
- `api/`: autenticación, tienda, pedidos y administración con tRPC.
- `contracts/catalog.ts`: catálogo inicial y categorías compartidas.
- `db/schema.ts`: tablas de usuarios, sesiones, productos y pedidos.
- `db/seed.ts`: carga inicial del catálogo y de Juan.
- `public/images/`: fotografías WebP servidas localmente.

## Docker

Con MySQL disponible y las variables de entorno configuradas:

```bash
docker build -t sabor-costeno .
docker run --rm -p 3000:3000 \
  -e APP_ID=sabor-costeno-local \
  -e APP_SECRET=una-clave-larga-y-aleatoria \
  -e DATABASE_URL=mysql://usuario:password@host:3306/sabor_costeno \
  sabor-costeno
```

Sustituye los valores de conexión por los de tu base de datos. El contenedor no incluye MySQL.

## Notas del prototipo

- El método de pago implementado es **contra entrega**; no se solicitan datos bancarios.
- El carrito pendiente se conserva en el navegador. Las cuentas, los productos y los pedidos confirmados se guardan en MySQL.
- Las fuentes tipográficas se cargan desde Google Fonts; el resto de los recursos visuales está incluido en el proyecto.
- Las fotografías son referencias gastronómicas, no imágenes de platos preparados por un restaurante específico. Consulta `CREDITOS_IMAGENES.md` y verifica los permisos de uso antes de una publicación comercial.
